#include<bits/stdc++.h>
using namespace std;
#include "PROCESS.h"

namespace example
{
    PROCESS::PROCESS()
    {
        AT = 0;
        BT = 0;
        CT = 0;
        WT = 0;
        TAT = 0;
        PID = 0;
        RT = 0;
        ST = 0;
    }
}
