#ifndef CPU_SCHEDULING
#define CPU_SCHEDULING

void FCFS();
void SJF();
void SRTF();
void PRIORITY_NP();
void PRIORITY_P();
void RoundRobin();
void LJF();
void LRTF();
void HRRN();
void MFQS();
void MQS();

#endif
